#!/bin/sh

nasm -f elf64 ai.s -o ai.o
gcc -static -Os -o example main.c ai.o
